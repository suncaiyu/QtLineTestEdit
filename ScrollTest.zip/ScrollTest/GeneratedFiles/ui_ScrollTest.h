/********************************************************************************
** Form generated from reading UI file 'ScrollTest.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCROLLTEST_H
#define UI_SCROLLTEST_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ScrollTestClass
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QScrollBar *verticalScrollBar;
    QSplitter *splitter;
    QPlainTextEdit *plainTextEdit;
    QPlainTextEdit *plainTextEdit_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *ScrollTestClass)
    {
        if (ScrollTestClass->objectName().isEmpty())
            ScrollTestClass->setObjectName(QString::fromUtf8("ScrollTestClass"));
        ScrollTestClass->resize(600, 400);
        centralWidget = new QWidget(ScrollTestClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalScrollBar = new QScrollBar(centralWidget);
        verticalScrollBar->setObjectName(QString::fromUtf8("verticalScrollBar"));
        verticalScrollBar->setOrientation(Qt::Vertical);

        verticalLayout->addWidget(verticalScrollBar);

        splitter = new QSplitter(centralWidget);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        plainTextEdit = new QPlainTextEdit(splitter);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        splitter->addWidget(plainTextEdit);
        plainTextEdit_2 = new QPlainTextEdit(splitter);
        plainTextEdit_2->setObjectName(QString::fromUtf8("plainTextEdit_2"));
        splitter->addWidget(plainTextEdit_2);

        verticalLayout->addWidget(splitter);

        ScrollTestClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(ScrollTestClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 23));
        ScrollTestClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(ScrollTestClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        ScrollTestClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(ScrollTestClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        ScrollTestClass->setStatusBar(statusBar);

        retranslateUi(ScrollTestClass);

        QMetaObject::connectSlotsByName(ScrollTestClass);
    } // setupUi

    void retranslateUi(QMainWindow *ScrollTestClass)
    {
        ScrollTestClass->setWindowTitle(QApplication::translate("ScrollTestClass", "ScrollTest", nullptr));
        plainTextEdit->setPlainText(QApplication::translate("ScrollTestClass", "s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"\n"
"s\n"
"s\n"
"s\n"
"s\n"
"s\n"
"ss", nullptr));
        plainTextEdit_2->setPlainText(QApplication::translate("ScrollTestClass", "c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"cc\n"
"c\n"
"c\n"
"\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c\n"
"c", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ScrollTestClass: public Ui_ScrollTestClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCROLLTEST_H
