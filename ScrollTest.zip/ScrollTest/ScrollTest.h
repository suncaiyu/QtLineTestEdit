#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_ScrollTest.h"

class ScrollTest : public QMainWindow
{
	Q_OBJECT

public:
	ScrollTest(QWidget *parent = Q_NULLPTR);

private:
	Ui::ScrollTestClass ui;
private slots:
	void on_verticalScrollBar_valueChanged(int value);
};
