#include "ScrollTest.h"
#include <qscrollbar.h>

ScrollTest::ScrollTest(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);

}
void ScrollTest::on_verticalScrollBar_valueChanged(int value) {
	QScrollBar *scrollbar1 = ui.plainTextEdit->verticalScrollBar();
	QScrollBar *scrollbar2 = ui.plainTextEdit_2->verticalScrollBar();
	ui.plainTextEdit_2->verticalScrollBar()->hide();
	ui.plainTextEdit->verticalScrollBar()->hide();
	ui.plainTextEdit->setWordWrapMode(QTextOption::NoWrap);
	scrollbar1->setValue(value);
	scrollbar2->setValue(value);
}
