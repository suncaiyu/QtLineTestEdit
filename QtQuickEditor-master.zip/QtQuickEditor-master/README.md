QtQuickEditor
=============

QtQuick Editor ,show line number

QtQuick
============

Qt quick user interface creator kit

how to use :

qmlviewer main.qml
